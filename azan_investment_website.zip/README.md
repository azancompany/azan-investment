# موقع أذهان للاستثمار

موقع ثابت (Static) مبني بـ HTML/CSS ومُستضاف مجانًا على GitHub Pages.